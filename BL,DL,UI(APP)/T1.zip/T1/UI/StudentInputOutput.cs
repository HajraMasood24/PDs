﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;
using T1.BL;

namespace T1.UI
{
    internal class StudentInputOutput
    {
        StudentBL studentBL ;
        public static void AddStudent()
        {
            Console.Write("Enter Student Name: ");
            string name = Console.ReadLine();

            Console.Write("Enter Student Age: ");
            int age = int.Parse(Console.ReadLine());

            Console.Write("Enter Student FSc Marks: ");
            int interMarks = int.Parse(Console.ReadLine());

            Console.Write("Enter Student ECAT Marks: ");
            int EcatMarks = int.Parse(Console.ReadLine());

            Console.Write("Enter number of prefrences: ");
            int prefrence = int.Parse(Console.ReadLine());

            Console.Write("Available Degree Programs: ");
            string availableProg = Console.ReadLine();

            Console.WriteLine(" ");
            StudentBL student = new StudentBL(name, age,interMarks, EcatMarks,00,prefrence);
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
        }
    }
}
