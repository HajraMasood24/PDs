﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace T1.BL
{
    internal class StudentBL
    {
        public string name;
        public int age;
        public float FSCMarks;
        public float EcatMarks;
        public float merit;

        public StudentBL()
        {

        }
        public StudentBL(string name, int age, float fSCMarks, float ecatMarks, float merit, List <DegreeProgramBL> prefrences)
        {
            this.name = name;
            this.age = age;
            this.FSCMarks = fSCMarks;
            this.EcatMarks = ecatMarks;
            this.merit = merit;
            prefrences = new List<DegreeProgramBL> ();
        }

        public void regStudentSubject(SubjectBL s)
        {

        }

        public void caculateMerit()
        {

        }

        public int getCreditHours()
        {
            return 0;
        }

        public float calculateFee()
        {
            return 0;
        }
    }
}

