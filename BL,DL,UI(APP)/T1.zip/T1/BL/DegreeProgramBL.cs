﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using T1.BL;

namespace T1
{
    internal class DegreeProgramBL
    {
        public string title;
        public string duration;
        public int seats;

        public DegreeProgramBL()
        {

        }

        public DegreeProgramBL(string title, string duration, int seats)
        {
            this.title = title;
            this.duration = duration;
            this.seats = seats;
        }
        
        public bool isSujectExists( SubjectBL sub )
        {
            return true;
        }
        
        public void AddSubject ( SubjectBL s)
        {

        }
        
        public int calculateCreditHours()
        {
            return 0;
        }
    }
}
